<?php 
session_start();

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iNoteBook - Login</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <div id='loading' class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
  <div id='body'>
  <?php
    include 'Comp/Navbar.php';
    ?>
     <form method="post">
<div class="container mt-4">
  <h1  class="text-center">Login Form</h1>
  <div class="row">

<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Username</label>
  <input type="text" required class="form-control" name="username" id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>


<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Password</label>
  <input required type="password" class="form-control" name='password' id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<button type="submit" name='submit' class="btn btn-primary">Login</button>
  </div>
</div>
</form>
</div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>


<?php

include 'Conn.php';
// Register here 

if (isset($_POST['submit'])){
  $u_name = $_POST['username'];
  $pass = $_POST['password'];

  $select = "SELECT * FROM `register` WHERE username='$u_name'";
  $select_run = mysqli_query($conn, $select);

  $read = mysqli_fetch_array($select_run);

  $_SESSION['username'] = $read['username'];

  if($read['pass'] == $pass){
    echo "<script>alert('Sucessfully Login')</script>";
    header('location:AddNote');
  }else{
    echo "<script>alert('Please fill Invalid Creditional')</script>";
  }

  
}



?>