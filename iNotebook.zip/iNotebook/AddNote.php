<?php
session_start();

if(!$_SESSION['username']){
  header('location:Login');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iNoteBook - AddNote</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
  <div id='loading' class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
  <div id='body'>
  <?php
    include 'Comp/Navbar.php';
    ?>
    <form method="post">
    <div class="container mt-4">
  <h1  class="text-center">Adding Note here</h1>
  <div class="row">
  <div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label"> Note's Heading</label>
  <input type="text" required class="form-control" name="heading" id="exampleFormControlInput1" placeholder="Enter the Note's Heading">
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Note's Subject</label>
  <input type="text" required class="form-control" name='subject' id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<div class="mb-3 col-md-12">
  <label for="exampleFormControlTextarea1" class="form-label">Note's Discription</label>
  <textarea required class="form-control" name='disc' id="exampleFormControlTextarea1" rows="10" placeholder="Note's Discription"></textarea>
</div>
<button type="submit" name="submit" class="btn btn-success">Add Note Button</button>
  </div>
</div>
</form>
</div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>


<?php
include 'Conn.php';

if(isset($_POST['submit'])){
  $title = $_POST['heading'];
  $subject = $_POST['subject'];
  $disc = $_POST['disc'];


  if(isset($_SESSION['username'])){
    $user = $_SESSION['username'];
    $select = "SELECT * FROM `register` WHERE username='$user'";
    $select_run = mysqli_query($conn, $select);
    $read = mysqli_fetch_array($select_run);
    $id = $read['id'];
    if($select_run){
      $d = date("Y-m-d");
      $insert = "INSERT INTO `inote`( `title`, `subject`, `described`, `userid`, `cdate`) VALUES ('$title','$subject','$disc','$id', '$d')";
      $insert_run = mysqli_query($conn, $insert);
      if($insert_run){
        echo "<script>alert('Add Note Succesfully')</script>";
      }else{
        echo "<script>alert('please try again !')</script>";
      }
    }
  }

}


?>