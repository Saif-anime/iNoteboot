
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="style.css">
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php $_SERVER['PHP_SELF']?>Home">iNoteBook</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php $_SERVER['PHP_SELF']?>Home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php $_SERVER['PHP_SELF']?>AddNote">AddNote</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php $_SERVER['PHP_SELF']?>NotesList">All Note</a>
        </li>

<?php  

if(!isset($_SESSION['username'])){
?>
    <li class='nav-item'>
  <a class='nav-link' href='<?php $_SERVER['PHP_SELF']?>Login'>Login</a>
</li>
<li class='nav-item'>
  <a class='nav-link' href='<?php $_SERVER['PHP_SELF']?>Register'>Register</a>
</li>

<?php

}else{
  ?>
    <li class='nav-item'>
  <a class='nav-link' href='<?php $_SERVER['PHP_SELF']?>Logout'>Logout</a>
</li>


<?php
}





?>
       
      </ul>
 
    </div>
  </div>
</nav>
<script src='index.js'></script>