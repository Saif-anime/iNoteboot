<?php
  session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iNoteBook - Home</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>

  <body>
  <div id='loading' class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    <div id='body'>
    <?php
    include 'Comp/Navbar.php';
    ?>
   
      <div class="d-flex" style="justify-content: center;
    align-items: center;
    flex-direction: column;
    height: 92.9vh;
    width: 100%;
    background: #a5b4fc; color:white;">
      <h4 style="font-family:math; font-size:40px">Welcome <?php
      include 'Conn.php';
      if(isset($_SESSION['username'])){
        $user = $_SESSION['username'];
        $select = "SELECT * FROM `register` WHERE username='$user'";
        $select_run = mysqli_query($conn, $select);

        $data = mysqli_fetch_array($select_run);
        echo $data['name'];
}

?></h4>
      <h1 style="font-family:math;font-size:50px">We are the MERN Stack Develeper</h1>
      </div>
      </div>
</body>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>