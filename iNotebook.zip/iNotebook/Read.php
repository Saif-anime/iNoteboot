<?php
session_start();

if(!$_SESSION['username']){
  header('location:Login');
}

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
  <div id='loading' class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>

      <div id="body">
      <?php
    include 'Comp/Navbar.php';
    ?>



  
  <div class="container">
    <div class="row">
        <?php
        
        include 'Conn.php';



        $ids = $_GET['ids'];
        
        $select="SELECT * FROM `inote` WHERE id='$ids'";

        $select_run = mysqli_query($conn, $select);

        $data_f = mysqli_fetch_array($select_run);

   
            $user = $_SESSION['username'];
            $select = "SELECT * FROM `register` WHERE username='$user'";
            $select_run = mysqli_query($conn, $select);
    
            $data = mysqli_fetch_array($select_run);
 

        ?>

<h1 class="text-center mt-2"> <?php echo $data_f['title']; ?></h1>
<p class="card-text"><small class="text-muted">Last updated <?php echo $data_f['cdate']; ?></small></p>
<h3 class="text-center"><?php echo $data_f['subject'] ?></h3>



<p style="text-align:justify;"><?php echo $data_f['described']; ?></p>
<footer class="blockquote-footer"> <?php echo $data['name']; ?>  <cite title="Source Title"><?php echo $data_f['subject']; ?></cite></footer>

<?php




        ?>
    
        </div>
    </div>
</div>    
</div>
      </body>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>








