<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iNoteBook - Register</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
  <div id='loading' class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
  <div id='body'>
  <?php
    include 'Comp/Navbar.php';
    ?>
    <form method='post'>
<div class="container mt-4">
  <h1  class="text-center">Register Form</h1>
  <div class="row">
  <div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label"> Name</label>
  <input type="text" class="form-control" required name="naam" id="exampleFormControlInput1" placeholder="Enter the Note's Heading">
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Email</label>
  <input type="text" required class="form-control" name="email" id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Class</label>
  <input type="text" required class="form-control" name='class' id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Stream</label>
  <select requiredd class="form-select" name='stream' aria-label="Default select example">
  <option value='0' selected>----Select Stream---</option>
  <option value="1">Art</option>
  <option value="2">Commerce</option>
  <option value="3">Science</option>
</select>
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Password</label>
  <input required type="password" class="form-control" name='password' id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Confirm Password</label>
  <input required type="text" class="form-control" name='cpass' id="exampleFormControlInput1" placeholder="Enter the Note's Subject">
</div>
<button type="submit" name='submit' class="btn btn-primary">Register</button>
  </div>
</div>
</form>

</div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>


<?php

include 'Conn.php';
// Register here 

if (isset($_POST['submit'])){
  $name = $_POST['naam'];
  $email = $_POST['email'];
  $stream = $_POST['stream'];
  $class = $_POST['class'];
  $pass = $_POST['password'];
  $cpass = $_POST['cpass'];

  $uname = $name."@$pass";


  if ( $pass == $cpass){
    $select = "SELECT * FROM `register` WHERE username='$uname'";
    $select_run = mysqli_query($conn, $select);
    $num = mysqli_num_rows($select_run);
    if($num>0){
      echo "<script>alert('this username is already exists please go through login page');</script>";
    }else{
      $insert = "INSERT INTO `register`( `name`, `username`, `email`, `class`, `stream`, `pass`) VALUES ('$name', '$uname', '$email','$class','$stream','$pass')";
      $insert_run = mysqli_query($conn, $insert);
      if($insert_run){
        echo "<script>alert('Your user name is $uname'); alert('Register Successfull !');</script>";
      }else{
        echo "<script>alert('Register Not Successfull !')</script>";
      }
    }


  }
}



?>