<?php
session_start();
unset($_SESSION['username']);

if(!isset($_SESSION['username'])){
    echo "<script>alert('Logout Successfull !')</script>";
    header('Location:Login');
}

?>