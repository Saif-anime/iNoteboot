<?php
$username = 'root'; 
$pass = '';
$server = 'localhost';
$dbname = 'inotebook';

$conn = mysqli_connect($server,$username, $pass, $dbname);

?>