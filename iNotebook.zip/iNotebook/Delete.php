<?php
include 'Conn.php';
$ids = $_GET['ids'];

$delete = "DELETE FROM `inote` WHERE id='$ids'";
$delete_run = mysqli_query($conn, $delete);

if($delete_run){
    echo "<script>alert('Delete succesfull !')</script>";
    header('Location:NotesList');
}else{
    echo "<script>alert('Delete not succesfull !')</script>";
    header('Location:NotesList');
}
?>