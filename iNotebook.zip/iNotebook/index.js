var body = document.querySelector('#body');
var loading = document.querySelector('#loading')
function loading_fun() {
    body.classList.remove('hide');
    document.body.classList.remove('loading');
    loading.classList.add('hide')
}


window.addEventListener('DOMContentLoaded', () => {
    body.classList.add('hide')
    document.body.classList.add('loading');

    setTimeout(() => {
        loading_fun();
    }, 800)
})