<?php
session_start();

if(!$_SESSION['username']){
  header('location:Login');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iNoteBook - NoteList</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
  <div id='loading' class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
  <div id='body'>
  <?php
    include 'Comp/Navbar.php';
    ?>
    <div class="container mt-3">
    
        <h1 class='text-center'>All Notes</h1>
      <form class="d-flex mt-2 mb-2" role="search">
        <input class="form-control me-2" name='search' type="search" placeholder="Search Note Here...." aria-label="Search">
        <button class="btn btn-warning" name='submit' type="submit">Search</button>
      </form>

    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Date</th>
      <th scope="col">Note's Heading</th>
      <th scope="col">Subject</th>
       <th scope="col" colspan="2" class='text-center'>Action</th>
    </tr>
  </thead>
  <tbody>

<?php
include 'Conn.php';
$user = $_SESSION['username'];

$select_user = "SELECT * FROM `register` WHERE username='$user'";
$select_user_run = mysqli_query($conn, $select_user);
$num_user = mysqli_num_rows($select_user_run);

// echo $num_user;

$user_fetch = mysqli_fetch_array($select_user_run);

$id = $user_fetch['id'];

// echo $id;

if(isset($_GET['submit'])){
  $search = $_GET['search'];
  $select = "SELECT * FROM `inote` WHERE title LIKE '%$search%' AND userid='$id'";
}else{
  $select = "SELECT * FROM `inote` WHERE userid='$id'";
}



$select_run = mysqli_query($conn, $select);

$num = mysqli_num_rows($select_run);

if($num>0){
   $i = 0;
  while($data = mysqli_fetch_array($select_run)){
    $i++;
    ?>
<tr>
      <th scope="row"><?php echo $i; ?></th>
      <td><?php echo $data['cdate']; ?></td>
      <td><a href="<?php $_SERVER['PHP_SELF']?>Read?ids=<?php echo $data['id'] ?>" class="text-decoration-none"><?php echo $data['title']; ?></a></td>
      <td><?php echo substr($data['subject'], 0, 50);?></td>
<td class='text-center'><a href="<?php $_SERVER['PHP_SELF']?>Delete?ids=<?php echo $data['id'] ?>" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a></td>
<td class='text-center'><a href="<?php $_SERVER['PHP_SELF']?>Update?ids=<?php echo $data['id'] ?>" class="btn btn-success"><i class="fa-solid fa-pen"></i></a></td>
    </tr>
<?php
  }
}else{
  echo "No Data found";
}

?>

  
   




  </tbody>
</table>
    </div>
</div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>